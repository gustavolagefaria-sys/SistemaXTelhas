// src/app/api/auditoria/route.js
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request) {
  const { searchParams } = new URL(request.url);

  // verificar permissão — tenta header primeiro, depois banco
  const usuarioIdHeader = request.headers.get("x-usuario-id");
  const perfilHeader    = request.headers.get("x-usuario-perfil");

  let isAdmin = perfilHeader?.toUpperCase() === "ADMIN";

  // se o header não veio, verifica no banco
  if (!isAdmin && usuarioIdHeader) {
    try {
      const u = await prisma.usuario.findUnique({
        where: { id: Number(usuarioIdHeader) },
        select: { perfil: true },
      });
      isAdmin = u?.perfil === "ADMIN";
    } catch {}
  }

  if (!isAdmin)
    return NextResponse.json({ error: "Acesso restrito a administradores." }, { status: 403 });

  const pagina   = Math.max(1, Number(searchParams.get("pagina") ?? 1));
  const limite   = Math.min(100, Math.max(1, Number(searchParams.get("limite") ?? 20)));
  const skip     = (pagina - 1) * limite;
  const exportar = searchParams.get("exportar");

  // filtros
  const where = {};
  const usuarioId  = searchParams.get("usuario_id");
  const tipoAcao   = searchParams.get("tipo_acao");
  const entidade   = searchParams.get("entidade");
  const dataInicio = searchParams.get("data_inicio");
  const dataFim    = searchParams.get("data_fim");

  if (usuarioId)  where.usuarioId = Number(usuarioId);
  if (tipoAcao)   where.tipoAcao  = tipoAcao;
  if (entidade)   where.entidade  = entidade;
  if (dataInicio || dataFim) {
    where.criadoEm = {};
    if (dataInicio) where.criadoEm.gte = new Date(dataInicio + "T00:00:00");
    if (dataFim)    where.criadoEm.lte = new Date(dataFim    + "T23:59:59");
  }

  try {
    // exportação CSV
    if (exportar === "csv") {
      const todos = await prisma.logAtividade.findMany({
        where,
        include: { usuario: { select: { nome: true, email: true } } },
        orderBy: { criadoEm: "desc" },
        take: 10000,
      });

      const cab = "ID,Usuario,Email,Tipo Acao,Entidade,Registro ID,Descricao,IP,Data Hora\n";
      const lin = todos.map(l => [
        l.id,
        `"${l.usuario.nome}"`,
        l.usuario.email,
        l.tipoAcao,
        l.entidade,
        l.registroId ?? "",
        `"${(l.descricao ?? "").replace(/"/g, "'")}"`,
        l.ip ?? "",
        new Date(l.criadoEm).toLocaleString("pt-BR"),
      ].join(",")).join("\n");

      return new Response(cab + lin, {
        headers: {
          "Content-Type":        "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="auditoria-${new Date().toISOString().slice(0,10)}.csv"`,
        },
      });
    }

    // consulta paginada
    const [total, logs] = await Promise.all([
      prisma.logAtividade.count({ where }),
      prisma.logAtividade.findMany({
        where,
        include: { usuario: { select: { id: true, nome: true, email: true } } },
        orderBy: { criadoEm: "desc" },
        skip,
        take: limite,
      }),
    ]);

    return NextResponse.json({
      total,
      pagina,
      limite,
      totalPaginas: Math.ceil(total / limite),
      logs,
    });

  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Erro ao buscar logs." }, { status: 500 });
  }
}
